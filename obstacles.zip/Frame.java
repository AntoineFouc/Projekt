import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

/*
Remarques :
Repenser la manière de créer les véhicules
Reflechir a permettre a chaque vehicule d acceder aux positions des autres afin de prevoir ensuite l'adaptation de sa vitesse en fonction de l'environnement
*/


public class Frame extends JFrame implements ActionListener, MouseListener, KeyListener{

	// Initialisation vehicules et routes (a mettre ailleurs plus tard)
	private Road road1 = new Road(800,370,0,370);
	private Road road2 = new Road(0,430,800,430);
	private Road road3 = new Road(370,0,370,800);
	private Road road4 = new Road(430,800,430,0);
	
	private Vehicule car1 = new Car(0.2,road1,200);
	private Vehicule car2 = new Car(0.35,road2,200);
	private Vehicule car3 = new Car(0.45,road3,200);
	private Vehicule car4 = new Car(0.15,road4,200);
	private Vehicule car5 = new Car(0.2,road1,600);

	public ArrayList<Vehicule> vehicules = new ArrayList<Vehicule>();		// liste des vehicules PRESENTS (cochés)
    public ArrayList<obstacle> obstacles = new ArrayList<obstacle>();       // liste des obstacles PRESENTS
    public ArrayList<Road> routes = new ArrayList<Road>();                  // liste des routes

    boolean appuyé=false;       //état de l'action clic souris
    boolean select=false;       //variable qqchose selectionné
    String quoi;                //type d'obstacle à placer

	private DisplayPanel p1;
	private JButton start;
	private JButton pause;
	private JButton restart;
    private JButton trash;

	// case pour cocher la presence des voiture 1 a 4
	private JCheckBox cb1; private boolean cb1On=false;
	private JCheckBox cb2; private boolean cb2On=false;
	private JCheckBox cb3; private boolean cb3On=false;
	private JCheckBox cb4; private boolean cb4On=false;
	private JCheckBox cb5; private boolean cb5On=false;

    // bouton feu rouge
    private JButton boutonFeu;
    private JTextField valeurFeu;
    private int valfeu;
    
    //bouton limitation
    private JButton boutonLimite;
    private JTextField valeurLimite;
    private int vallim;
    
    //bouton barriere
    private JButton boutonBarriere;
    

	public Frame(){
		setTitle("K-Roof");
		setLayout(null);
		setSize(1115,840);
		setResizable(false);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


		// Panneau affichage
		p1 = new DisplayPanel(this);
		p1.setLayout(null);
		p1.setBounds(0,0,800,800);
        p1.addMouseListener(this);
		add(p1);

		// Panneau interface
		JPanel p2 = new JPanel();
		p2.setLayout(null);
		p2.setBackground(new Color(230,230,230));
		p2.setBounds(800,0,300,800);
		add(p2);

		// bouton start
		start = new JButton(new ImageIcon("Images/start.png"));
		start.setBounds(10,680,135,50);
		start.setBackground(new Color(0,170,0));
		start.addActionListener(this);
		p2.add(start);

		// bouton pause
		pause = new JButton(new ImageIcon("Images/pause.png"));
		pause.setBounds(155,680,135,50);
		pause.setBackground(new Color(250,20,20));
		pause.addActionListener(this);
		p2.add(pause);
		pause.setEnabled(false); 				// desactive le bouton au debut

		// bouton restart
		restart = new JButton("Recommencer");
		restart.setBounds(10,740,280,50);
		restart.addActionListener(this);
		p2.add(restart);
		restart.setEnabled(false); 				// desactive le bouton au debut
        
        //bouton trash
        trash = new JButton(new ImageIcon("Images/corbeille.png"));
		trash.setBounds(155,620,135,50);
		trash.setBackground(new Color(191,191,191));
		trash.addActionListener(this);
		p2.add(trash);
		trash.setEnabled(true); 



		// check boxes vehicules
		cb1 = new JCheckBox("Voiture 1");
		cb1.setBounds(20,10,100,25);
		cb1.addActionListener(this);
		p2.add(cb1);

		cb2 = new JCheckBox("Voiture 2");
		cb2.setBounds(20,45,100,25);
		cb2.addActionListener(this);
		p2.add(cb2);

		cb3 = new JCheckBox("Voiture 3");
		cb3.setBounds(20,80,100,25);
		cb3.addActionListener(this);
		p2.add(cb3);

		cb4 = new JCheckBox("Voiture 4");
		cb4.setBounds(20,115,100,25);
		cb4.addActionListener(this);
		p2.add(cb4);

		cb5 = new JCheckBox("Voiture 5");
		cb5.setBounds(20,150,100,25);
		cb5.addActionListener(this);
		p2.add(cb5);
        
        // bouton feu rouge
		boutonFeu = new JButton(new ImageIcon("Images/feurouge.png"));
		boutonFeu.setBounds(20,195,60,135);
		boutonFeu.addMouseListener(this);
        boutonFeu.setVisible(true);
		p2.add(boutonFeu);
        
        //valeur feu rouge
        valeurFeu = new JTextField("Intervalle");
        valeurFeu.setBounds(20,340,60,30);
        valeurFeu.setVisible(true);
        p2.add(valeurFeu);
        
        // bouton limites
		boutonLimite = new JButton(new ImageIcon("Images/limitation.png"));
		boutonLimite.setBounds(100,195,70,70);
		boutonLimite.addMouseListener(this);
        boutonLimite.setVisible(true);
		p2.add(boutonLimite);
        
        //valeur limites
        valeurLimite = new JTextField("Limite");
        valeurLimite.setBounds(100,340,70,30);
        valeurLimite.setVisible(true);
        p2.add(valeurLimite);

        routes.add(road1);
        routes.add(road2);
        routes.add(road3);
        routes.add(road4);
        
        //bouton barrière
        boutonBarriere = new JButton(new ImageIcon("Images/barriere.png"));
        boutonBarriere.setBounds(190,195,62,40);
		boutonBarriere.addMouseListener(this);
        boutonBarriere.setVisible(true);
        p2.add(boutonBarriere);
	}

	public void actionPerformed(ActionEvent e){

		if(e.getSource() == start){
			start.setEnabled(false);
			pause.setEnabled(true);
			restart.setEnabled(true);

			// ne permet pas d enlever ou rajouter des voitures une fois l animation lancee
			cb1.setEnabled(false);
			cb2.setEnabled(false);
			cb3.setEnabled(false);
			cb4.setEnabled(false);
			cb5.setEnabled(false);

			for(Vehicule v : vehicules){
				v.setVehicules(vehicules);
			}

			p1.getTimer().start(); // commence le chrono dans p1 (DisplayPanel) lorsqu'on appuie sur le bouton
		}

		if(e.getSource() == pause){				// met en pause la simulation
			p1.getTimer().stop();
			pause.setEnabled(false);
			start.setEnabled(true);
		}

		if(e.getSource() == restart){           //bouton restart
			pause.setEnabled(false);
			restart.setEnabled(false);

			cb1.setEnabled(true);
			cb2.setEnabled(true);
			cb3.setEnabled(true);
			cb4.setEnabled(true);
			cb5.setEnabled(true);

			cb1.setSelected(false);
			cb2.setSelected(false);
			cb3.setSelected(false);
			cb4.setSelected(false);
			cb5.setSelected(false);

			cb1On=false;
			cb2On=false;
			cb3On=false;
			cb4On=false;
			cb5On=false;

			vehicules.clear();
			p1.repaint();
            valeurFeu.setText("Intervalle");
            valeurLimite.setText("Limite");

			car1.setPosition(0);
			car2.setPosition(0);
			car3.setPosition(0);
			car4.setPosition(0);
			car5.setPosition(400);

			p1.getTimer().stop();
			p1.setTime(0);

			start.setEnabled(true);
		}

        if(e.getSource() == trash){
            ArrayList<obstacle> supprimer = new ArrayList<>();
            for(obstacle o : obstacles){
				supprimer.add(o);
			}
            obstacles.removeAll(supprimer);
            p1.repaint();
        }


		if(e.getSource() == cb1){
			cb1On = !cb1On;
			if(cb1On) vehicules.add(car1);
			else vehicules.remove(car1);
			p1.repaint();
		}

		if(e.getSource() == cb2){
			cb2On = !cb2On;
			if(cb2On) vehicules.add(car2);
			else vehicules.remove(car2);
			p1.repaint();
		}

		if(e.getSource() == cb3){
			cb3On = !cb3On;
			if(cb3On) vehicules.add(car3);
			else vehicules.remove(car3);
			p1.repaint();
		}

		if(e.getSource() == cb4){
			cb4On = !cb4On;
			if(cb4On) vehicules.add(car4);
			else vehicules.remove(car4);
			p1.repaint();
		}

		if(e.getSource() == cb5){
			cb5On = !cb5On;
			if(cb5On) vehicules.add(car5);
			else vehicules.remove(car5);
			p1.repaint();
		}

	}

	public void mouseEntered(MouseEvent e){}

	public void mouseExited(MouseEvent e){}

	public void mousePressed(MouseEvent e){
        if(obstacles.contains(e.getSource())){ 
            if(SwingUtilities.isRightMouseButton(e)){
                //Supprimer l'obstacle
                obstacles.remove(e.getSource());
                p1.repaint();
            }
        } else if (SwingUtilities.isLeftMouseButton(e)){
            if(e.getSource()==boutonFeu){
                appuyé=true;
                quoi="feurouge"; //coiffeur haha
            } else if(e.getSource()==boutonLimite){
                appuyé=true;
                quoi="limitation";
            } else if(e.getSource()==boutonBarriere){
                appuyé=true;
                quoi="barriere";
            }
        }
    }

	public void mouseReleased(MouseEvent e){
        if(appuyé){
            ajouterElement(quoi);
        }
    }

	public void mouseClicked(MouseEvent e){
        if(e.getSource()==boutonFeu&&SwingUtilities.isLeftMouseButton(e)&&!select){ //feu rouge
            select=true;
            quoi="feurouge";
        } else if (e.getSource()==boutonLimite&&SwingUtilities.isLeftMouseButton(e)&&!select){ //limitation
            select=true;
            quoi="limitation";
        } else if (e.getSource()==boutonBarriere&&SwingUtilities.isLeftMouseButton(e)&&!select){ //barriere
            select=true;
            quoi="barriere";
        } else if (select&&quoi.equals("feurouge")){
            if(e.getSource()==p1&&SwingUtilities.isLeftMouseButton(e)){
                ajouterElement("feurouge");
                select=false;
            } else {
                select=false;
            }
        } else if (select&&quoi.equals("limitation")){
            if(e.getSource()==p1&&SwingUtilities.isLeftMouseButton(e)){
                ajouterElement("limitation");
                select=false;
            } else {
                select=false;
            }
        } else if (select&&quoi.equals("barriere")){
            if(e.getSource()==p1&&SwingUtilities.isLeftMouseButton(e)){
                ajouterElement("barriere");
                select=false;
            } else {
                select=false;
            }
        }
    }

	public void keyPressed(KeyEvent e){}

	public void keyReleased(KeyEvent e){}

	public void keyTyped(KeyEvent e){}


    public boolean checkPos(int x,int y, ArrayList<Road> routes){
        boolean verif=true;
        return verif;
    }
    
    public int getRoute(int x, int y, ArrayList<Road> routes){
        int rep=-1;
        int liste=0;
        for(Road r:routes){
            int x1=r.getStartingPoint()[0];
            int x2=r.getEndingPoint()[0];
            int y1=r.getStartingPoint()[1];
            int y2=r.getEndingPoint()[1];
            if((x>=Math.min(x1,x2)-29)&&(x<=Math.max(x1,x2)+29)&&y>=(Math.min(y1,y2)-29)&&(y<=Math.max(y1,y2)+29)){
                rep=routes.indexOf(r);
                liste++;
            }
        }
        if(liste>1){
            rep=-1;
        }
        return rep;
    }
    
    public void ajouterElement(String valeur){
            PointerInfo a = MouseInfo.getPointerInfo();
            Point b = a.getLocation();
            int x = (int) b.getX()-this.getLocationOnScreen().x;
            int y = (int) b.getY()-this.getLocationOnScreen().y-38;
            if((x<=p1.getWidth())&&(y<=p1.getHeight())&&(x>=0)&&(y>=0)){ //Check si relaché dans la map
                int pos = getRoute(x,y,routes);
                if(pos!=-1){ //check si le point choisi est dans une route et pas un carrefour
                    //ajouter obstacle
                    if(valeur.equals("feurouge")){   //cas feu rouge
                        if(isInt(valeurFeu.getText())){
                            valfeu=Integer.valueOf(valeurFeu.getText());
                        } else {
                            valfeu=0;
                        }
                        feurouge feu=new feurouge(x,y,routes.get(pos),valfeu);
                        obstacles.add(feu);
                        p1.repaint();
                    } else if (valeur.equals("limitation")){   //cas limitation
                        if(isInt(valeurLimite.getText())){
                            vallim=Integer.valueOf(valeurLimite.getText());
                        } else {
                            vallim=0;
                        }
                        limitation limite=new limitation(x,y,routes.get(pos),vallim);
                        obstacles.add(limite);
                        p1.repaint();
                    } else if (valeur.equals("barriere")){   //cas barriere
                        barriere bar=new barriere(x,y,routes.get(pos));
                        obstacles.add(bar);
                        p1.repaint();
                    }
                }
            }
        }
        
    public static boolean isInt(String strNum) {
    if (strNum == null) {
        return false;
    }
    try {
        int d = Integer.parseInt(strNum);
    } catch (NumberFormatException nfe) {
        return false;
    }
    return true;
}
}




