public class Main{
	public static void main(String[] args){
		Frame mainFrame = new Frame();		// lance la fenetre principale
	}
}
