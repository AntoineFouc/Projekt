public class stop extends obstacle{
    
    protected int voiebloq;
    
    public stop(int uneposx,int uneposy,int unevoiebloq){
        super(5,5,uneposx,uneposy);
        voiebloq=unevoiebloq;
    }
}
 
