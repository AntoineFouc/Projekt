# Projekt
Projet algo 2022

La classe Main.java permet de lancer la fenetre principale (et unique) Frame.java

Frame.java contient un panneau d'affichage p1 de type DisplayArray et un panneau d'interaction p2

Le DisplayPanel p1 contient le chrono, et permet l'affichage du fond et des vehicules au cours du temps

La classe Road.java permet de creer des routes a partir de 2 points (depart et arrivee) -> sens!

La classe Vehicule.java permet de creer des vehicules en leur assignant une vitesse initiale et une route

La classe Car.java, fille de Vehicule.java, permet de creer un vehicule de taille predefinie








